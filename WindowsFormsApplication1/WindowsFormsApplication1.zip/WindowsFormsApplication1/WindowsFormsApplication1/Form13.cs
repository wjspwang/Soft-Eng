﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form13 : Form
    {
        MySqlConnection conn;
        public Form previousform;
        string[] week = new string[] { "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday" };

        public Form13()
        {
            InitializeComponent();
            Form2 f2 = new Form2();
            conn = new MySqlConnection("server=localhost;Database=System_db1;uid=root; Pwd =root ;");
        }

        int num;
        private void loadall()
        {
            /*string query3 = "select b.staff_id, concat(c.lname, ', ', c.fname) as Employee,d.start_date from staff_sched a JOIN  staff b ON a.staff_id = b.staff_id JOIN person c ON b.person_id = c.person_id JOIN schedule d ON a.sched_id = d.sched_id  where d.start_date >= '1/7/2018' AND d.end_date <= '7/7/2018' ORDER BY d.start_date";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            conn.Close();
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;
            */

            //string day = DateTime.Now.ToString("dddd");

            //1 loop thru database table to get date and name
            //2 convert date to word
            //3 get the num
            //4 
            /*

            string day = DateTime.Now.ToString("dddd");
            if (day == "Sunday")
            {
                num = 0;
            }
            else if (day == "Monday")
            {
                num = 1;
            }
            else if (day == "Tuesday")
            {
                num = 2;
            }
            else if (day == "Wednesday")
            {
                num = 3;
            }
            else if (day == "Thursday")
            {
                num = 4;
            }
            else if (day == "Friday")
            {
                num = 5;
            }
            else if (day == "Saturday")
            {
                num = 6;
            }*/


            //MessageBox.Show(day + " " + num);

            //MessageBox.Show(start_date + " " + end_date);

            //string query1 = "select b.staff_id, concat(c.lname, ', ', c.fname) as Employee,d.start_date,d.end_date,d.activity from staff_sched a JOIN  staff b ON a.staff_id = b.staff_id JOIN person c ON b.person_id = c.person_id JOIN schedule d ON a.sched_id = d.sched_id  where d.start_date >= '" + start_date+ "' AND d.end_date <= '"+end_date+"' ORDER BY d.start_date";
            //MessageBox.Show(query1);
            /*
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            DataTable dt = new DataTable();
            adp.Fill(dt);

            conn.Close();
            dataGridView1.DataSource = dt;
           */

            // dataGridView1.Rows[0].Cells[num].Value = day;

            //looping through database
            int now = getNum(DateTime.Now);
            DateTime start_date = DateTime.Now.AddDays(-now);
            DateTime end_date = start_date.AddDays(6);
            MessageBox.Show(start_date.ToString("dd/MM/yyyy"));

            string query5 = "select concat(c.lname, ', ', c.fname) as Employee,d.start_date,d.end_date " +
                "from staff_sched a " +
                "JOIN  staff b ON a.staff_id = b.staff_id " +
                "JOIN person c ON b.person_id = c.person_id " +
                "JOIN schedule d ON a.sched_id = d.sched_id " +
                " where d.start_date >= '" 
                + start_date.ToString("yyyy/MM/dd") + "' AND d.end_date <= '" + end_date.ToString("yyyy/MM/dd") 
                + "' ORDER BY d.start_date ";
            conn.Open();
            MySqlCommand comm5 = new MySqlCommand(query5, conn);
            MySqlDataAdapter adp5 = new MySqlDataAdapter(comm5);
            conn.Close();
            DataTable dt5 = new DataTable();
            adp5.Fill(dt5);
            
            DateTime[] dateTimes = new DateTime[dt5.Rows.Count];
            DateTime[] endTimes = new DateTime[dt5.Rows.Count];
            string[] empName = new string[dt5.Rows.Count];
            
            for(int i=0; i < dt5.Rows.Count; i++)
            {
                dateTimes[i] = Convert.ToDateTime(dt5.Rows[i]["start_date"]);
                endTimes[i] = Convert.ToDateTime(dt5.Rows[i]["end_date"]);
                //MessageBox.Show(dt5.Rows[1][i+1].ToString());
                //dateTimes[i] = DateTime.ParseExact(dt5.Rows[1][i+1].ToString(), "yyyy/MM/dd", null);
                empName[i] = Convert.ToString(dt5.Rows[i]["Employee"]);
                MessageBox.Show("" + dateTimes[i] + " " + empName[i] );

            }

            List<String> Repeats = new List<string>();
            //string day;
            int num=0;
            for (int a = 0; a < dateTimes.Length; a++)
            {
               Repeats.Clear();
               num= getNum(dateTimes[a]);
                for(int j = 0; j < dateTimes.Length; j++)
                {

                    if (dateTimes[a].ToString("dddd") == dateTimes[j].ToString("dddd"))
                    {

                        Repeats.Add(empName[j] + " " + dateTimes[a] + " " + endTimes[a]);
                        Repeats.Add("————————————");

                    }



                }


                //dataGridView1.Rows[0].Cells[num].Value = empName[a] +" "+ dateTimes[a] +" "+ endTimes[a];
                dataGridView1.Rows[0].Cells[num].Value = String.Join(System.Environment.NewLine, Repeats);


                //MessageBox.Show("" + dataGridView1.Rows[0].Cells[num].Value);


            }
            

            string query = "select count(*) from staff_sched a " +
                "JOIN  staff b ON a.staff_id = b.staff_id " +
                "JOIN person c ON b.person_id = c.person_id " +
                "JOIN schedule d ON a.sched_id = d.sched_id  " +
                "where d.start_date >= '" + start_date.ToString("yyyy/MM/dd") + "' " +
                "AND d.end_date <= '" + end_date.ToString("yyyy/MM/dd") + "' " +
                "ORDER BY d.start_date";
            conn.Open();
            MySqlCommand comm1 = new MySqlCommand(query, conn);
            MySqlDataReader rdr = comm1.ExecuteReader();
            conn.Close();


            conn.Open();
            label1.Text = comm1.ExecuteScalar().ToString();

            conn.Close();

            conn.Close();

        }

        private int getNum(DateTime d)
        {
           String day = d.ToString("dddd");
            int num=0;
            if (day == "Sunday")
            {
                num = 0;
            }
            else if (day == "Monday")
            {
                num = 1;
            }
            else if (day == "Tuesday")
            {
                num = 2;
            }
            else if (day == "Wednesday")
            {
                num = 3;
            }
            else if (day == "Thursday")
            {
                num = 4;
            }
            else if (day == "Friday")
            {
                num = 5;
            }
            else if (day == "Saturday")
            {
                num = 6;
            }

            return num;

        }

        private void Form13_Load(object sender, EventArgs e)
        {
            loadall();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
