﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form11 : Form
    {
        MySqlConnection conn;
        public Form previousform;
        public Form11()
        {
            InitializeComponent();
            Form2 f2 = new Form2();
            conn = new MySqlConnection("server=localhost;Database=System_db1;uid=root; Pwd = root;");
        }

        private void Form11_Load(object sender, EventArgs e)
        {
            loadall();
        }
        public void loadall()
        {
            string query = " select * from order_line ;";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            conn.Close();
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;

            dataGridView1.Columns["order_line_id"].Visible = false;
            dataGridView1.Columns["date_time"].HeaderText = "Date of Transaction";
            dataGridView1.Columns["invoice_id"].HeaderText = "Invoice #";
            dataGridView1.Columns["prod_id"].HeaderText = "Item Code";
            dataGridView1.Columns["prodname"].HeaderText = "Item Name";
            dataGridView1.Columns["category"].HeaderText = "Category";
            dataGridView1.Columns["prod_unit"].HeaderText = "Unit of Measure";
            dataGridView1.Columns["prod_quant"].HeaderText = "Product Quantity";
            dataGridView1.Columns["prod_price"].HeaderText = "Product Price";
            dataGridView1.Columns["total"].HeaderText = "Total Price";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }
    }
}
