﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form9 : Form
    {
        MySqlConnection conn;
        public Form previousform;
        public Form9()
        {
            InitializeComponent();
            Form2 f2 = new Form2();
            conn = new MySqlConnection("server=localhost;Database=System_db1;uid=root; Pwd =root ;");
        }
        private void executeQuery(string q)
        {
            conn.Open();
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            loadall();
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            loadall();
            
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox22_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void user_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           /* string query = "INSERT INTO staff_schedule(staff_id) " +
                                "VALUES('" + staff_text.Text + "')";
            conn.Open();

            MySqlCommand comm = new MySqlCommand(query, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Schedule Added");
            */
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form13 a = new Form13();
            a.Show();
            a.previousform = this;
        }
        private int selected_user_id2 = 0;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                selected_user_id2 = int.Parse(sched_grid.Rows[e.RowIndex].Cells["staff_sched_id"].Value.ToString());
                
                //date_box1.Text = sched_grid.Rows[e.RowIndex].Cells["date_time"].Value.ToString();
                //act_box1.Text = sched_grid.Rows[e.RowIndex].Cells["activity"].Value.ToString();
                
                
               // selected_user_id2 = int.Parse(sched_grid.Rows[e.RowIndex].Cells["sched_id"].Value.ToString());

                date_box.Text = sched_grid.Rows[e.RowIndex].Cells["start_date"].Value.ToString();
                end_datebox.Text = sched_grid.Rows[e.RowIndex].Cells["end_date"].Value.ToString();
                act_box.Text = sched_grid.Rows[e.RowIndex].Cells["activity"].Value.ToString();
                

            }
           // MessageBox.Show(selected_user_id.ToString());
        }
        private int selected_user_id = 0;
        private void staff_grid_CellContentClick(object sender, DataGridViewCellEventArgs e)
                {
                    if (e.RowIndex > -1)
                    {

                        selected_user_id = int.Parse(staff_grid.Rows[e.RowIndex].Cells["person_id"].Value.ToString());
                        staff_text.Text = staff_grid.Rows[e.RowIndex].Cells["person_id"].Value.ToString();
                        name.Text = staff_grid.Rows[e.RowIndex].Cells["Employee"].Value.ToString();

                    }
            MessageBox.Show(selected_user_id.ToString());
        }
        private void loadall()
        {

            //string query = "select b.staff_id, concat( lname, ', ' ,fname) AS Employee from person a, staff b where a.person_id = b.person_id AND person_type = 2";
            string query = "select person_id, concat( lname, ', ' ,fname) AS Employee from person a WHERE person_type = 2";
            //conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            conn.Close();
            DataTable dt = new DataTable();
            adp.Fill(dt);

            staff_grid.DataSource = dt;

            staff_grid.Columns["person_id"].HeaderText = "Staff ID";




            string query1 = "select staff_sched_id, concat(c.lname, ', ', c.fname) as Employee,d.start_date, d.end_date,d.activity from staff_sched a, staff b, person c, schedule d where c.person_id = b.person_id AND b.staff_id = a.staff_id AND a.sched_id = d.sched_id AND a.staff_id = "+selected_user_id+";";
            //string query1 = "select * from schedule";
                conn.Open();
                MySqlCommand comm1 = new MySqlCommand(query1, conn);
                MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1);
                DataTable dt1 = new DataTable();
                adp1.Fill(dt1);

                sched_grid.DataSource = dt1;
           

            sched_grid.Columns["staff_sched_id"].HeaderText = "Staff Schedule No.";
            sched_grid.Columns["start_date"].HeaderText = "Date Start";
            sched_grid.Columns["start_date"].HeaderText = "Date End";
            sched_grid.Columns["activity"].HeaderText = "Activity";





        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void Form9_Activated(object sender, EventArgs e)
        {
            loadall();
        }


        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            scheduling a = new scheduling();
            a.Show();
            a.previousform = this;
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }
    }
}
