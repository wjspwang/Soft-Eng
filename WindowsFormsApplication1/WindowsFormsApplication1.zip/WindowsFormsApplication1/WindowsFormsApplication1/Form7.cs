﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace WindowsFormsApplication1
{
    public partial class Form7 : Form
    {
        MySqlConnection conn;
        public Form previousform;
        public Form7()
        {
            InitializeComponent();
            Form2 f2 = new Form2();
            conn = new MySqlConnection("server=localhost;Database=System_db1;uid=root; Pwd = ;");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            textBox1.ForeColor = Color.Black;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.ForeColor = Color.Black;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            textBox3.ForeColor = Color.Black;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            textBox4.ForeColor = Color.Black;
        }

        private void textBox4_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Product Name";
                
            }
            if (textBox2.Text == "")
            {
                textBox2.Text = "Product Price";
            }
            if (textBox3.Text == "")
            {
                textBox3.Text = "Quantity";
            }
            if (textBox4.Text == "Total")
            {
                textBox4.Text = "";
            }
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "Product Name")
            {
                textBox1.Text = "";
            }
            if (textBox2.Text == "")
            {
                textBox2.Text = "Product Price";
            }
            if (textBox3.Text == "")
            {
                textBox3.Text = "Quantity";
            }
            if (textBox4.Text == "")
            {
                textBox4.Text = "Total";
            }
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Product Name";
            }
            if (textBox2.Text == "Product Price")
            {
                textBox2.Text = "";
            }
            if (textBox3.Text == "")
            {
                textBox3.Text = "Quantity";
            }
            if (textBox4.Text == "")
            {
                textBox4.Text = "Total";
            }
        }

        private void textBox3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                textBox1.Text = "Product Name";
            }
            if (textBox2.Text == "")
            {
                textBox2.Text = "Product Price";
            }
            if (textBox3.Text == "Quantity")
            {
                textBox3.Text = "";
            }
            if (textBox4.Text == "")
            {
                textBox4.Text = "Total";
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();


            id.Clear();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }
    }
}
