﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form8 : Form
    {

        MySqlConnection conn;
        public Form previousform;
        public Form8()
        {
            InitializeComponent();
            Form2 f2 = new Form2();
            conn = new MySqlConnection("server=localhost;Database=System_db1;uid=root; Pwd = root;");
        }
        double Total;
        public int invoice = 1;
        float price;
        int quant;
        float pos_total;
        float percent;
        int invoiceNum = 0001;
        

        private void Form8_Load(object sender, EventArgs e)
        {
            loadall();
            textBox5.Text = Convert.ToString(0);
            textBox7.Text = Convert.ToString(0);
            textBox13.Text = Convert.ToString(0);

            float.TryParse(textBox5.Text, out price);
            int.TryParse(textBox7.Text, out quant);

            textBox6.Text = Convert.ToString(price * quant);

        }
        private int tmp;
        private void loadall()
        {
            current_Invoice();
            MessageBox.Show(tmp + "");
            textBox14.Text = Convert.ToString(invoice);
            string query = " select * from order_line where invoice_id = "+tmp+" ;";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            conn.Close();
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView1.DataSource = dt;

            dataGridView1.Columns["order_line_id"].Visible = false;
            dataGridView1.Columns["date_time"].HeaderText = "Date of Transaction";
            dataGridView1.Columns["invoice_id"].HeaderText = "Invoice #";
            dataGridView1.Columns["prod_id"].HeaderText = "Item Code";
            dataGridView1.Columns["prodname"].HeaderText = "Item Name";
            dataGridView1.Columns["category"].HeaderText = "Category";
            dataGridView1.Columns["prod_unit"].HeaderText = "Unit of Measure";
            dataGridView1.Columns["prod_quant"].HeaderText = "Product Quantity";
            dataGridView1.Columns["prod_price"].HeaderText = "Product Price";
            dataGridView1.Columns["total"].HeaderText = "Total Price";


            string query1 = "select * from recipe_list";
            conn.Open();
            MySqlCommand comm1 = new MySqlCommand(query1, conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1);
            conn.Close();
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);

            dataGridView2.DataSource = dt1;

            dataGridView2.DataSource = dt1;
            dataGridView2.Columns["recipe_id"].Visible = false;
            dataGridView2.Columns["recipe_name"].HeaderText = "Dish Name";
            dataGridView2.Columns["recipe_desc"].HeaderText = "Description";
            dataGridView2.Columns["recipe_cat"].HeaderText = "Category";
            dataGridView2.Columns["recipe_cost"].HeaderText = "Selling Price";
            dataGridView2.Columns["recipe_unit"].HeaderText = "Unit";


            string query3 = " SELECT COUNT(prod_id) FROM order_line";
            conn.Open();
            MySqlCommand comm3 = new MySqlCommand(query3, conn);
            MySqlDataReader rdr = comm3.ExecuteReader();
            conn.Close();

            conn.Open();
            textBox2.Text = comm3.ExecuteScalar().ToString();
            conn.Close();

            string query4 = "SELECT SUM(total) FROM order_line;";
            conn.Open();
            MySqlCommand comm4 = new MySqlCommand(query4, conn);
            MySqlDataReader rdr1 = comm4.ExecuteReader();
            conn.Close();

            conn.Open();
            textBox10.Text = comm4.ExecuteScalar().ToString();
            conn.Close();

        
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form5 a = new Form5();
            a.Show();
            a.previousform = this;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }
        private int selected_user_id;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            dataGridView1.ReadOnly = true;
            if (e.RowIndex > -1)
            {
                selected_user_id = int.Parse(dataGridView1.Rows[e.RowIndex].Cells["order_line_id"].Value.ToString());

                

            }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if(textBox1.Text == "")
            {
                string query = "select * from order_line where date_time >= '" + fromdate.Value.ToString("yyyy-MM-dd") + "' and date_time <= '" + todate.Value.ToString("yyyy-MM-dd") + "' ";
                MessageBox.Show(query);
                conn.Open();
                MySqlCommand comm = new MySqlCommand(query, conn);
                MySqlDataAdapter adp = new MySqlDataAdapter(comm);
                conn.Close();
                DataTable dt = new DataTable();
                adp.Fill(dt);

                dataGridView1.DataSource = dt;
            }
            else
            {
            string query1 = "select * from order_line where invoice_id = '"+textBox1.Text+"' AND date_time >= '"+fromdate.Value.ToString("yyyy-MM-dd") + "' and date_time <= '"+todate.Value.ToString("yyyy-MM-dd") + "' ";
                        MessageBox.Show(query1);
                        conn.Open();
                        MySqlCommand comm1 = new MySqlCommand(query1, conn);
                        MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1);
                        conn.Close();
                        DataTable dt1 = new DataTable();
                        adp1.Fill(dt1);

                        dataGridView1.DataSource = dt1;
            }
            
        }
        private int selected_user_id1;
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            lowStocks();
            if (e.RowIndex > -1)
            {

                selected_user_id1 = int.Parse(dataGridView2.Rows[e.RowIndex].Cells["recipe_id"].Value.ToString());
                textBox3.Text = dataGridView2.Rows[e.RowIndex].Cells["recipe_name"].Value.ToString();
                textBox5.Text = dataGridView2.Rows[e.RowIndex].Cells["recipe_cost"].Value.ToString();
                //textBox4.Text = dataGridView2.Rows[e.RowIndex].Cells["description"].Value.ToString();
                //textBox5.Text = dataGridView2.Rows[e.RowIndex].Cells["recipe_cost"].Value.ToString();
                textBox9.Text = dataGridView2.Rows[e.RowIndex].Cells["recipe_unit"].Value.ToString();
                textBox8.Text = dataGridView2.Rows[e.RowIndex].Cells["recipe_cat"].Value.ToString();
                textBox16.Text = dataGridView2.Rows[e.RowIndex].Cells["recipe_id"].Value.ToString();
            }
            textBox7.Text = Convert.ToString(0);
            string query = "select a.prodid, a.prodquant, a.restock_val from product a, recipe_item_list b, recipe_list c where c.recipe_id = "+selected_user_id1+" AND c.recipe_id = b.recipe_id AND a.prodid = b.prod_id ";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            conn.Close();
            DataTable dt = new DataTable();
            adp.Fill(dt);

            dataGridView3.DataSource = dt;


        }
        public class lowstockprod
        {
            public string name { get; set; }
        }
        private void lowStocks()
        {
            string query = "select count(prodname) from product a, recipe_item_list b, recipe_list c where c.recipe_id = " + selected_user_id1 + " AND prodquant <= restock_val AND c.recipe_id = b.recipe_id AND a.prodid = b.prod_id";
            conn.Open();
            MySqlCommand comm3 = new MySqlCommand(query, conn);
            MySqlDataReader rdr = comm3.ExecuteReader();
            conn.Close();

            conn.Open();
            lowstock.Text = comm3.ExecuteScalar().ToString();
            conn.Close();

            
            


        }
        private void noStock()
        {
            string query = "select count(prodname) from product a, recipe_item_list b, recipe_list c where c.recipe_id = " + selected_user_id1 + " AND prodquant <= 0 AND c.recipe_id = b.recipe_id AND a.prodid = b.prod_id";
            conn.Open();
            MySqlCommand comm3 = new MySqlCommand(query, conn);
            MySqlDataReader rdr = comm3.ExecuteReader();
            conn.Close();

            conn.Open();
            nostock.Text = comm3.ExecuteScalar().ToString();
            conn.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            
            
            //-------------------------------------------------------------------------------------------------------------------------------------------------------//
            /*if (textBox16.Text == "" || textBox3.Text == "" || textBox8.Text == "" || textBox9.Text == "" || textBox5.Text == "" || textBox7.Text == "" || textBox6.Text == "")
            {
                MessageBox.Show("Please Complete the form");
            }
            else*/ if (Convert.ToInt32(textBox7.Text) == 0)
            {
                MessageBox.Show("Please Fill Up Quantity Required Field", "Point of Sale", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            else
            {
                string query1 = "SELECT COUNT(prod_id) from order_line where order_line.prod_id = '" + selected_user_id1 + "' ";
                conn.Open();
                MySqlCommand comm1 = new MySqlCommand(query1, conn);
                MySqlDataReader rdr = comm1.ExecuteReader();
                conn.Close();


                conn.Open();
                nostock.Text = comm1.ExecuteScalar().ToString();
                conn.Close();

                Total = Convert.ToDouble(textBox5.Text) * Convert.ToDouble(textBox7.Text);
                textBox6.Text = Convert.ToString(Total);
                if(Convert.ToInt32(nostock.Text) > 0)
                {
                    string query2 = "select prodname from product a, recipe_item_list b, recipe_list c where c.recipe_id = " + selected_user_id1 + " AND prodquant <= restock_val AND c.recipe_id = b.recipe_id AND a.prodid = b.prod_id ";
                    conn.Open();
                    MySqlCommand comm = new MySqlCommand(query2, conn);
                    MySqlDataReader reader = comm.ExecuteReader();
                    StringBuilder productNames = new StringBuilder();
                    while (reader.Read())
                    {
                        productNames.Append(reader["prodname"].ToString() + Environment.NewLine);
                    }
                    conn.Close();
                    MessageBox.Show("Out of Stocks", "Please Re-Stock", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    MessageBox.Show("Following Products need to restock: " + productNames, "Out of ingredients", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }
                else if (Convert.ToInt32(lowstock.Text) > 0)
                {
                    string query2 = "select prodname from product a, recipe_item_list b, recipe_list c where c.recipe_id = " + selected_user_id1 + " AND prodquant <= restock_val AND c.recipe_id = b.recipe_id AND a.prodid = b.prod_id ";
                    conn.Open();
                    MySqlCommand comm = new MySqlCommand(query2, conn);
                    MySqlDataReader reader = comm.ExecuteReader();
                    StringBuilder productNames = new StringBuilder();
                    while (reader.Read())
                    {
                        productNames.Append(reader["prodname"].ToString() + Environment.NewLine);
                    }
                    conn.Close();
                    MessageBox.Show("Warning Low Stocks", "Low Stocks", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    MessageBox.Show("Following Products need to restock: " + productNames, "Out of ingredients", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    //return;
                }
                if (Convert.ToInt32(label13.Text) == 0)
                {
                    MessageBox.Show("ITEM ADDED TO THE ORDER");
                    string query = "INSERT INTO order_line(date_time, invoice_id, prod_id, prodname, category, prod_unit, prod_quant, prod_price, total) VALUES(CURRENT_DATE, '" + textBox14.Text + "', '" + current_invoice.Text + "', '" + textBox3.Text + "', '" + textBox8.Text + "', '" + textBox9.Text + "', '" + textBox7.Text + "', '" + textBox5.Text + "', '" + textBox6.Text + "');";
                    conn.Open();

                    MySqlCommand comm = new MySqlCommand(query, conn);
                    comm.ExecuteNonQuery();
                    conn.Close();
                    loadall();
                }
                else
                {
                    MessageBox.Show("ITEM UPDATED");
                    string query = " update order_line set prod_quant =  prod_quant + '" + textBox7.Text + "' , total = total + '" + textBox6.Text +"' where prod_id = '" + textBox16.Text + "' ";
                    conn.Open();
                    MessageBox.Show(textBox1.Text);
                    MySqlCommand comm = new MySqlCommand(query, conn);
                    comm.ExecuteNonQuery();
                    conn.Close();
                    loadall();
                }

            }



            //invoice = invoice + 1;
        }




        
        
        private void current_Invoice()
        {
            string query1 = "select max(invoice_id) from sales_tbl";
            conn.Open();
            MySqlCommand comm1 = new MySqlCommand(query1, conn);
            MySqlDataReader rdr = comm1.ExecuteReader();
            conn.Close();


            conn.Open();
            tmp = (int)comm1.ExecuteScalar();
            current_invoice.Text = tmp.ToString();
            conn.Close();
        }
        
        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            DialogResult iExit;
            iExit = MessageBox.Show("Confirm if you want to delete this item", "Point of Sale", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            if (iExit == DialogResult.Yes)
            {
                string query = "DELETE FROM order_line WHERE order_line_id = '" + selected_user_id + "' ";
                conn.Open();
                MySqlCommand comm = new MySqlCommand(query, conn);
                comm.ExecuteNonQuery();
                conn.Close();
                loadall();
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            Total = Convert.ToDouble(textBox5.Text) * Convert.ToDouble(textBox7.Text);
            textBox6.Text = Convert.ToString(Total);
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void textBox7_KeyDown(object sender, KeyEventArgs e)
        {
            /*if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3 || e.KeyCode == Keys.D4 ||
                e.KeyCode == Keys.D5 || e.KeyCode == Keys.D6 || e.KeyCode == Keys.D7 || e.KeyCode == Keys.D8 || e.KeyCode == Keys.D9 || e.KeyCode == Keys.D0)
            {
                int.TryParse(textBox5.Text, out val1);
                int.TryParse(textBox7.Text, out val2);

                textBox6.Text = Convert.ToString(val1 * val2);
            }*/

            if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3 || e.KeyCode == Keys.D4 ||
                e.KeyCode == Keys.D5 || e.KeyCode == Keys.D6 || e.KeyCode == Keys.D7 || e.KeyCode == Keys.D8 || e.KeyCode == Keys.D9 || e.KeyCode == Keys.Back
                || e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.NumPad3 || e.KeyCode == Keys.NumPad4
                 || e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.NumPad6 || e.KeyCode == Keys.NumPad7 || e.KeyCode == Keys.NumPad8 || e.KeyCode == Keys.NumPad9)
            {
                float.TryParse(textBox5.Text, out price);
                int.TryParse(textBox7.Text, out quant);

                textBox6.Text = Convert.ToString(price * quant);
            }
        }

        private void textBox7_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3 || e.KeyCode == Keys.D4 ||
                e.KeyCode == Keys.D5 || e.KeyCode == Keys.D6 || e.KeyCode == Keys.D7 || e.KeyCode == Keys.D8 || e.KeyCode == Keys.D9 || e.KeyCode == Keys.Back
                || e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.NumPad3 || e.KeyCode == Keys.NumPad4
                 || e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.NumPad6 || e.KeyCode == Keys.NumPad7 || e.KeyCode == Keys.NumPad8 || e.KeyCode == Keys.NumPad9)
            {
                float.TryParse(textBox5.Text, out price);
                int.TryParse(textBox7.Text, out quant);

                textBox6.Text = Convert.ToString(price * quant);
            }
          
        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back && e.KeyChar != '.')
            {
                e.Handled = true;
            }
        }

        private void textBox11_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back)
            {
                e.Handled = true;
            }
        }

        private void textBox11_KeyDown(object sender, KeyEventArgs e)
        {
            
                if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3 || e.KeyCode == Keys.D4 ||
                    e.KeyCode == Keys.D5 || e.KeyCode == Keys.D6 || e.KeyCode == Keys.D7 || e.KeyCode == Keys.D8 || e.KeyCode == Keys.D9 || e.KeyCode == Keys.Back
                    || e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.NumPad3 || e.KeyCode == Keys.NumPad4
                     || e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.NumPad6 || e.KeyCode == Keys.NumPad7 || e.KeyCode == Keys.NumPad8 || e.KeyCode == Keys.NumPad9)
                {


                    float.TryParse(textBox10.Text, out pos_total);
                    float.TryParse(textBox11.Text, out percent);

                    float rate = percent / 100;




                    label17.Text = Convert.ToString(pos_total - pos_total * rate);
                    double discounted = pos_total - pos_total * rate;

                }
                
            
        }

        private void textBox11_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.D0 || e.KeyCode == Keys.D1 || e.KeyCode == Keys.D2 || e.KeyCode == Keys.D3 || e.KeyCode == Keys.D4 ||
                e.KeyCode == Keys.D5 || e.KeyCode == Keys.D6 || e.KeyCode == Keys.D7 || e.KeyCode == Keys.D8 || e.KeyCode == Keys.D9 || e.KeyCode == Keys.Back
                || e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.NumPad3 || e.KeyCode == Keys.NumPad4
                 || e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.NumPad6 || e.KeyCode == Keys.NumPad7 || e.KeyCode == Keys.NumPad8 || e.KeyCode == Keys.NumPad9)
            {


                    float.TryParse(textBox10.Text, out pos_total);
                    float.TryParse(textBox11.Text, out percent);

                    float rate = percent / 100;




                    label17.Text = Convert.ToString(pos_total - pos_total * rate);
                    double discounted = pos_total - pos_total * rate;
                
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if(comboBox1.Text == "")
            {
                comboBox1.Text = Convert.ToString(0);
            }
            else if (Convert.ToInt32(comboBox1.Text) >= 100)
            {
                MessageBox.Show("Invalid Discount Ammount", "Invalid Input", MessageBoxButtons.OK);
            }
            else
            if (Convert.ToDouble(textBox13.Text) < Convert.ToDouble(label17.Text))
            {
                MessageBox.Show("Invalid Paid Amount", "Invalid Input", MessageBoxButtons.OK);

            }else if(Convert.ToDouble(textBox13.Text) < Convert.ToDouble(textBox10.Text))
                {
                MessageBox.Show("Invalid Paid Amount", "Invalid Input", MessageBoxButtons.OK);
            }
            else 
            {



                float total, tendered, payable;
                if (label18.Text == Convert.ToString(0))
                {
                    label18.Text = Convert.ToString(0);
                    label27.Text = Convert.ToString(0);
                    float.TryParse(textBox13.Text, out tendered);
                    float.TryParse(textBox10.Text, out total);
                    label29.Text = Convert.ToString(tendered - total);
                    label25.Text = textBox2.Text;
                    label26.Text = textBox10.Text;
                    label28.Text = textBox13.Text;
                }
                else
                {
                    float.TryParse(label17.Text, out payable);
                    float.TryParse(textBox13.Text, out tendered);
                    //MessageBox.Show(Convert.ToString(tendered + "-" + payable  ));
                    label29.Text = Convert.ToString(tendered - payable);
                    label25.Text = textBox2.Text;
                    label26.Text = textBox10.Text;
                    label27.Text = textBox11.Text;
                    label18.Text = label17.Text;
                    label28.Text = textBox13.Text;
                }

              

                string query = "update product, recipe_item_list set product.prodquant = product.prodquant - recipe_item_list.prod_quant where recipe_item_list.prod_id = product.prodid ";
                conn.Open();
                MySqlCommand comm = new MySqlCommand(query, conn);
                comm.ExecuteNonQuery();
                conn.Close();
                loadall();
                if (Convert.ToDouble(label29.Text) >= 0)
                {
                    

                    Print a = new Print();
                    a.Show();
                    a.previousform = this;

                    int cinvoice = Convert.ToInt32(current_invoice.Text);
                    cinvoice += 1;
                    current_invoice.Text = cinvoice.ToString();
                }
            }
           

            /*
            int height = dataGridView1.Height;
            dataGridView1.Height = dataGridView1.RowCount * dataGridView1.RowTemplate.Height * 2;
            bmp = new Bitmap(dataGridView1.Width, dataGridView1.Height);
            dataGridView1.DrawToBitmap(bmp, new Rectangle(0, 0, dataGridView1.Width, dataGridView1.Height));
            dataGridView1.Height = height;
            //PrintPreviewDialog.ShowDialog();
            */
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click_2(object sender, EventArgs e)
        {
            loadall();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string query1 = "select * from order_line where invoice_id = '" + textBox1.Text + "'  ";
            MessageBox.Show(query1);
            conn.Open();
            MySqlCommand comm1 = new MySqlCommand(query1, conn);
            MySqlDataAdapter adp1 = new MySqlDataAdapter(comm1);
            conn.Close();
            DataTable dt1 = new DataTable();
            adp1.Fill(dt1);

            dataGridView1.DataSource = dt1;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO sales_tbl(invoice_id)  VALUES('" + textBox14.Text + "' )";
            conn.Open();

            MySqlCommand comm = new MySqlCommand(query, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            loadall();
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_KeyDown(object sender, KeyEventArgs e)
        {
 

            
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void comboBox1_KeyUp(object sender, KeyEventArgs e)
        {
 

            
        }

        private void comboBox1_SelectedValueChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            float.TryParse(textBox10.Text, out pos_total);
            float.TryParse(comboBox1.Text, out percent);

            float rate = percent / 100;




            label17.Text = Convert.ToString(pos_total - pos_total * rate);
            double discounted = pos_total - pos_total * rate;
        }

        private void comboBox1_Click(object sender, EventArgs e)
        {
            
        }
    }
 }


