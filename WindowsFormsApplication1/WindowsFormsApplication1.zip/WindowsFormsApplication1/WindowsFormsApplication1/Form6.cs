﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form6 : Form
    {
        MySqlConnection conn;
        public Form previousform;
        public Form6()
        {
            InitializeComponent();
            Form2 f2 = new Form2();
            conn = new MySqlConnection("server=localhost;Database=System_db1;uid=root; Pwd = root;");
        }
        private void executeQuery(string q)
        {
            conn.Open();
            MySqlCommand comm = new MySqlCommand(q, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            loadall();
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void contact(object sender, EventArgs e)
        {

        }

        private void textBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_Click(object sender, EventArgs e)
        {

        }

        private void num_Click(object sender, EventArgs e)
        {
 
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {


                selected_user_id = int.Parse(dataGridView1.Rows[e.RowIndex].Cells["id"].Value.ToString());
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["first"].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells["last"].Value.ToString();
                comboBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["gen"].Value.ToString();
                num.Text = dataGridView1.Rows[e.RowIndex].Cells["contact"].Value.ToString();
                id.Text = dataGridView1.Rows[e.RowIndex].Cells["id"].Value.ToString();
            }
        }
        private int selected_user_id;
        private void loadall()
        {

            string query = "select * from person where person_type = 1";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            conn.Close();
            DataTable dt = new DataTable();
            adp.Fill(dt);
           
            dataGridView1.DataSource = dt;


            string query2 = "select * from person where person_type = 2";
            conn.Open();
            MySqlCommand comm2 = new MySqlCommand(query2, conn);
            MySqlDataAdapter adp2 = new MySqlDataAdapter(comm2);
            conn.Close();
            DataTable dt2 = new DataTable();
            adp2.Fill(dt2);

            dataGridView3.DataSource = dt2;

         

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            loadall();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO person(fname,lname,person_type) " +
                "VALUES('" + textBox1.Text + "', '" + textBox2.Text + "', 1)";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            loadall();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query = "";
            if (String.IsNullOrEmpty(id.Text)) { MessageBox.Show("Choose a user to edit or input id to edit.", "Test", MessageBoxButtons.OK, MessageBoxIcon.Information); }
            else
            {
                if (String.IsNullOrEmpty(textBox1.Text)) query += ""; else query += " UPDATE customer SET first='" + textBox1.Text + "' WHERE custid='" + id.Text + "'; ";
                if (String.IsNullOrEmpty(textBox2.Text)) query += ""; else query += "UPDATE customer SET last='" + textBox2.Text + "' WHERE custid='" + id.Text + "'; ";
                if (String.IsNullOrEmpty(num.Text)) query += ""; else query += "UPDATE customer SET contact='" +num.Text + "' WHERE custid='" + id.Text + "'; ";
                if (String.IsNullOrEmpty(comboBox1.Text)) query += ""; else query += "UPDATE customer SET gen='" + comboBox1.Text + "' WHERE custid='" + id.Text + "'; ";
                executeQuery(query);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            comboBox1.ResetText();
            num.Clear();
            
            id.Clear();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM customer WHERE id = '" + selected_user_id + "'; ";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            loadall();
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO person(fname,lname,person_type) " +
                "VALUES('" + textBox8.Text + "', '" + textBox9.Text + "', 2)";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            loadall();
            string query1 = "select person_id from person where person_id = (select max(person_id) from person) AND person_type = 2 ";
            conn.Open();
            MySqlCommand comm3 = new MySqlCommand(query1, conn);
            MySqlDataReader rdr = comm3.ExecuteReader();
            conn.Close();

            conn.Open();
            person_id.Text = comm3.ExecuteScalar().ToString();
            conn.Close();
            loadall();
            string query2 = "INSERT INTO staff(person_id) " +
                "VALUES('" + person_id.Text + "')";
            conn.Open();
            MySqlCommand comm2 = new MySqlCommand(query2, conn);
            comm2.ExecuteNonQuery();
            conn.Close();
            loadall();
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
    }
    }

