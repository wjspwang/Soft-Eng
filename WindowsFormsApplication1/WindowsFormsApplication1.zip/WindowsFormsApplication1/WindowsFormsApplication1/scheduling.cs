﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class scheduling : Form
    {
        MySqlConnection conn;
        public Form previousform;
        public scheduling()
        {
            InitializeComponent();
            conn = new MySqlConnection("server=localhost;Database=System_db1;uid=root; Pwd =root ;");
        }

        private void scheduling_Load(object sender, EventArgs e)
        {

        }

        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT INTO schedule(date_time, activity) " +
                                "VALUES('" + dateTimePicker1.Text + "','" + comboBox1.Text + "' )";
            conn.Open();

            MySqlCommand comm = new MySqlCommand(query, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Schedule Added");
        }
    }
}
