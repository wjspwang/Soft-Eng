﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form12 : Form
    {
        MySqlConnection conn;
        public Form previousform;

        public Form12()
        {
        InitializeComponent();
        conn = new MySqlConnection("server=localhost; Database=System_db1; uid=root; Pwd=root ;");

        }
        private void LoadAll()
        {
            string query = "select id, last, first from customer ; ";
            conn.Open();
            MySqlCommand comm = new MySqlCommand(query, conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(comm);
            conn.Close();
            DataTable dt = new DataTable();
            adp.Fill(dt);
            dataGridView1.DataSource = dt;

            dataGridView1.Columns["id"].HeaderText = "Customer ID";
            dataGridView1.Columns["last"].HeaderText = "Lastname";
            dataGridView1.Columns["first"].HeaderText = "Firstname";
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form12_Load(object sender, EventArgs e)
        {
            LoadAll();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            previousform.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "INSERT into rating_tbl(cust_id,rating_val,feed_back) VALUES("+id_text.Text+","+rating_box.Text+",'"+feedback_text.Text+"' );";
            conn.Open();

            MySqlCommand comm = new MySqlCommand(query, conn);
            comm.ExecuteNonQuery();
            conn.Close();
            LoadAll();
        }
    }
}
